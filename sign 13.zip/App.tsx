
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import LessonPath from './components/LessonPath';
import PracticeTab from './components/PracticeTab';
import SignsTab from './components/SignsTab';
import ExerciseScreen from './components/ExerciseScreen';
import { UNITS } from './constants';
import { UserStats, Lesson, Difficulty } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [showSummary, setShowSummary] = useState(false);
  const [lastXpGained, setLastXpGained] = useState(0);
  const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.INTERMEDIATE);

  const [stats, setStats] = useState<UserStats>({
    xp: 0,
    streak: 3,
    hearts: 5,
    gems: 420,
    completedLessons: []
  });

  const handleStartLesson = (lessonId: string) => {
    const lesson = UNITS.flatMap(u => u.lessons).find(l => l.id === lessonId);
    if (lesson) {
      setActiveLesson(lesson);
    }
  };

  const handleStartPractice = (lesson: Lesson) => {
    setActiveLesson(lesson);
  };

  const handleFinishLesson = (xpGained: number) => {
    if (activeLesson) {
      const isRealLesson = UNITS.flatMap(u => u.lessons).some(l => l.id === activeLesson.id);
      
      setStats(prev => ({
        ...prev,
        xp: prev.xp + xpGained,
        completedLessons: isRealLesson 
          ? [...new Set([...prev.completedLessons, activeLesson.id])]
          : prev.completedLessons
      }));
      setLastXpGained(xpGained);
      setActiveLesson(null);
      setShowSummary(true);
    }
  };

  return (
    <div className="flex min-h-screen bg-white text-[#4b4b4b]">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 pb-20 lg:pb-0">
        <Header stats={stats} />
        
        <div className="max-w-4xl mx-auto">
          {activeTab === 'home' && (
            <LessonPath 
              units={UNITS} 
              completedLessons={stats.completedLessons}
              onStartLesson= {handleStartLesson}
              difficulty={difficulty}
              setDifficulty={setDifficulty}
            />
          )}

          {activeTab === 'practice' && (
            <PracticeTab 
              stats={stats} 
              onStartPractice={handleStartPractice} 
            />
          )}

          {activeTab === 'signs' && (
            <SignsTab onStartPractice={handleStartPractice} />
          )}
        </div>
      </main>

      {activeLesson && (
        <ExerciseScreen 
          lesson={activeLesson}
          difficulty={difficulty}
          onQuit={() => setActiveLesson(null)}
          onFinish={handleFinishLesson}
        />
      )}

      {showSummary && (
        <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-6 backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-8 max-w-sm w-full flex flex-col items-center text-center shadow-2xl animate-in zoom-in duration-300">
            <div className="w-32 h-32 bg-[#58cc02] rounded-full flex items-center justify-center text-white text-5xl mb-6">
              <i className="fa-solid fa-trophy"></i>
            </div>
            <h2 className="text-3xl font-black text-[#4b4b4b] mb-2 uppercase tracking-tight">Session Complete!</h2>
            <p className="text-gray-500 font-bold mb-8">You're making amazing progress in ASL.</p>
            
            <div className="grid grid-cols-2 gap-4 w-full mb-8">
              <div className="bg-[#ff9600] p-4 rounded-2xl text-white">
                <div className="text-xs font-bold uppercase opacity-80">XP Gained</div>
                <div className="text-2xl font-black">{lastXpGained}</div>
              </div>
              <div className="bg-[#1cb0f6] p-4 rounded-2xl text-white">
                <div className="text-xs font-bold uppercase opacity-80">Accuracy</div>
                <div className="text-2xl font-black">100%</div>
              </div>
            </div>

            <button
              onClick={() => setShowSummary(false)}
              className="w-full bg-[#58cc02] text-white py-4 rounded-2xl font-black uppercase tracking-wider shadow-[0_4px_0_0_#46a302] hover:translate-y-1 hover:shadow-none transition-all"
            >
              Continue
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
