
export enum ExerciseType {
  MULTIPLE_CHOICE = 'MULTIPLE_CHOICE',
  SIGN_PRACTICE = 'SIGN_PRACTICE',
  WATCH_AND_IDENTIFY = 'WATCH_AND_IDENTIFY'
}

// Added Difficulty enum to support app-wide difficulty settings
export enum Difficulty {
  EASY = 'EASY',
  INTERMEDIATE = 'INTERMEDIATE',
  HARD = 'HARD'
}

export interface Exercise {
  id: string;
  type: ExerciseType;
  question: string;
  targetSign?: string;
  options?: string[];
  correctOption?: string;
  imageUrl?: string;
}

export interface Lesson {
  id: string;
  title: string;
  exercises: Exercise[];
}

export interface Unit {
  id: string;
  title: string;
  description: string;
  lessons: Lesson[];
  color: string;
}

export interface UserStats {
  xp: number;
  streak: number;
  hearts: number;
  gems: number;
  completedLessons: string[];
}